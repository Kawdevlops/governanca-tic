from pydantic import BaseModel, Field
from typing import Optional
from enum import Enum


class CategoriaRisco(str, Enum):
    GOVERNANCA = "governanca"
    CONTRATO = "contrato"
    OPERACIONAL = "operacional"
    SEGURANCA = "seguranca"
    DADOS = "dados"
    INFRAESTRUTURA = "infraestrutura"
    SISTEMAS = "sistemas"
    FINANCEIRO = "financeiro"


class StatusRisco(str, Enum):
    ABERTO = "aberto"
    EM_ANALISE = "em_analise"
    EM_TRATAMENTO = "em_tratamento"
    MITIGADO = "mitigado"
    ENCERRADO = "encerrado"


class RiscoBase(BaseModel):
    identificador: str = Field(..., min_length=3, max_length=50)
    nome: str = Field(..., min_length=3, max_length=180)
    descricao: Optional[str] = None
    categoria: CategoriaRisco

    probabilidade: int = Field(..., ge=1, le=5)
    impacto: int = Field(..., ge=1, le=5)
    criticidade: int = Field(..., ge=1, le=5)
    exposicao: int = Field(..., ge=1, le=5)
    prejuizo: int = Field(..., ge=1, le=5)

    origem: Optional[str] = None
    responsavel: Optional[str] = None
    status: StatusRisco = StatusRisco.ABERTO

    def calcular_pontuacao(self) -> int:
        return (
            self.probabilidade * self.impacto
            + self.criticidade
            + self.exposicao
            + self.prejuizo
        )

    def classificar_nivel(self) -> str:
        pontuacao = self.calcular_pontuacao()

        if pontuacao <= 10:
            return "baixo"

        if pontuacao <= 20:
            return "moderado"

        if pontuacao <= 30:
            return "alto"

        return "critico"

    def gerar_dados_para_banco(self) -> dict:
        dados = self.model_dump(mode="json")
        dados["pontuacao"] = self.calcular_pontuacao()
        dados["nivel"] = self.classificar_nivel()
        return dados


class RiscoCreate(RiscoBase):
    pass


class RiscoUpdate(BaseModel):
    nome: Optional[str] = None
    descricao: Optional[str] = None
    categoria: Optional[CategoriaRisco] = None

    probabilidade: Optional[int] = Field(None, ge=1, le=5)
    impacto: Optional[int] = Field(None, ge=1, le=5)
    criticidade: Optional[int] = Field(None, ge=1, le=5)
    exposicao: Optional[int] = Field(None, ge=1, le=5)
    prejuizo: Optional[int] = Field(None, ge=1, le=5)

    origem: Optional[str] = None
    responsavel: Optional[str] = None
    status: Optional[StatusRisco] = None


class RiscoResponse(RiscoBase):
    element_id: str
    pontuacao: int
    nivel: str

class RiscoVinculo(BaseModel):
    tipo_alvo: str
    identificador_alvo: str