from neo4j import AsyncDriver
from app.models.risco import RiscoCreate, RiscoResponse, RiscoVinculo

class RiscoRepository:
    def __init__(self, driver: AsyncDriver):
        self.driver = driver

    def _mapear(self, registro: dict) -> RiscoResponse:
        # Resposta organizada da API.
        return RiscoResponse(**registro)

    async def obter_por_identificador(self, identificador: str) -> RiscoResponse | None:
        async with self.driver.session() as session:
            result = await session.run("""
                MATCH (r:Risco {identificador: $identificador})
                RETURN
                    elementId(r) AS element_id,
                    r.identificador AS identificador,
                    r.nome AS nome,
                    r.descricao AS descricao,
                    r.categoria AS categoria,
                    r.probabilidade AS probabilidade,
                    r.impacto AS impacto,
                    r.criticidade AS criticidade,
                    r.exposicao AS exposicao,
                    r.prejuizo AS prejuizo,
                    r.origem AS origem,
                    r.responsavel AS responsavel,
                    r.status AS status,
                    r.pontuacao AS pontuacao,
                    r.nivel AS nivel
            """, identificador=identificador)

            registro = await result.single()

        if not registro:
            return None

        return self._mapear(dict(registro))

    async def criar(self, payload: RiscoCreate) -> RiscoResponse:
        props = payload.gerar_dados_para_banco()

        async with self.driver.session() as session:
            result = await session.run("""
                CREATE (r:Risco)
                SET r += $props
                RETURN
                    elementId(r) AS element_id,
                    r.identificador AS identificador,
                    r.nome AS nome,
                    r.descricao AS descricao,
                    r.categoria AS categoria,
                    r.probabilidade AS probabilidade,
                    r.impacto AS impacto,
                    r.criticidade AS criticidade,
                    r.exposicao AS exposicao,
                    r.prejuizo AS prejuizo,
                    r.origem AS origem,
                    r.responsavel AS responsavel,
                    r.status AS status,
                    r.pontuacao AS pontuacao,
                    r.nivel AS nivel
            """, props=props)

            registro = await result.single()

        return self._mapear(dict(registro))

    async def listar(self) -> list[RiscoResponse]:
        async with self.driver.session() as session:
            result = await session.run("""
                MATCH (r:Risco)
                RETURN
                    elementId(r) AS element_id,
                    r.identificador AS identificador,
                    r.nome AS nome,
                    r.descricao AS descricao,
                    r.categoria AS categoria,
                    r.probabilidade AS probabilidade,
                    r.impacto AS impacto,
                    r.criticidade AS criticidade,
                    r.exposicao AS exposicao,
                    r.prejuizo AS prejuizo,
                    r.origem AS origem,
                    r.responsavel AS responsavel,
                    r.status AS status,
                    r.pontuacao AS pontuacao,
                    r.nivel AS nivel
                ORDER BY r.pontuacao DESC
            """)

            registros = await result.data()
        return [self._mapear(dict(registro)) for registro in registros]

    async def atualizar(self, identificador: str, payload: RiscoCreate) -> RiscoResponse | None:
   
        dados = payload.gerar_dados_para_banco()

        async with self.driver.session() as session:
            result = await session.run("""
                MATCH (r:Risco {identificador: $identificador})
                SET r += $dados
                RETURN
                    elementId(r) AS element_id,
                    r.identificador AS identificador,
                    r.nome AS nome,
                    r.descricao AS descricao,
                    r.categoria AS categoria,
                    r.probabilidade AS probabilidade,
                    r.impacto AS impacto,
                    r.criticidade AS criticidade,
                    r.exposicao AS exposicao,
                    r.prejuizo AS prejuizo,
                    r.origem AS origem,
                    r.responsavel AS responsavel,
                    r.status AS status,
                    r.pontuacao AS pontuacao,
                    r.nivel AS nivel
            """, identificador=identificador, dados=dados)

            registro = await result.single()

        if not registro:
            return None

        return self._mapear(dict(registro))

    async def deletar(self, identificador: str) -> bool:
        async with self.driver.session() as session:
            result = await session.run("""
                MATCH (r:Risco {identificador: $identificador})
                WITH r, count(r) AS total
                DETACH DELETE r
                RETURN total > 0 AS removido
            """, identificador=identificador)

            registro = await result.single()

        return bool(registro and registro["removido"])

    async def vincular(self, identificador: str, vinculo: RiscoVinculo) -> bool:
        #vinculo generalista, caso for vincular ações do pdstic especifica ai simplifica
        labels = {
            "servico": "ServicoTIC",
            "sistema": "Sistema",
            "contrato": "Contrato",
            "acao_pdstic": "AcaoPDSTIC",
            "ativo": "AtivoTIC",
            "unidade": "Unidade"
        }

        label = labels.get(vinculo.tipo_alvo)

        if not label:
            return False

        query = f"""
            MATCH (r:Risco {{identificador: $identificador}})
            MATCH (alvo:{label} {{identificador: $identificador_alvo}})  // aqui ele busca pelo indentificador porém no serviço não há indentificador 
            MERGE (r)-[:AFETA]->(alvo)
            RETURN count(alvo) AS total
        """

        async with self.driver.session() as session:
            result = await session.run(
                query,
                identificador=identificador,
                identificador_alvo=vinculo.identificador_alvo
            )

            registro = await result.single()

        return registro["total"] > 0